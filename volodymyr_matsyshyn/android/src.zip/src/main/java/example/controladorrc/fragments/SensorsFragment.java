package example.controladorrc.fragments;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import example.controladorrc.BluetoothConnection;
import example.controladorrc.R;

public class SensorsFragment extends Fragment implements SensorEventListener {

    private BluetoothConnection bc;

    private SensorManager sensorManager;
    private Sensor sensor;

    private ImageButton imageButton;
    private boolean sensorActive = false;

    private String deviceAddress = null;
    private OutputStream outputStream;
    private InputStream inputStream;
    private BluetoothAdapter myBluetooth = null;
    private BluetoothSocket btSocket = null;
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private TextView ejeVertical;
    private TextView ejeHorizontal;

    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.layout_fragment_sensors, container, false);

        bc = new BluetoothConnection();

        ejeVertical = (TextView) view.findViewById(R.id.ejeVertical);
        ejeHorizontal = (TextView) view.findViewById(R.id.ejeHorizontal);

        imageButton = (ImageButton) view.findViewById(R.id.sensor_on_off);
        sensorButtonPressed();

        if (getArguments() != null) {
            deviceAddress = getArguments().getString("deviceAddress");
            ejeHorizontal.setText(deviceAddress);
        }

        myBluetooth = BluetoothAdapter.getDefaultAdapter();

        connectBT();

        sensorManager = (SensorManager) this.getActivity().getSystemService(Activity.SENSOR_SERVICE);

        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        return view;
    }

    public void sensorButtonPressed(){
        imageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(sensorActive){
                    imageButton.setImageResource(R.drawable.button_icon_green);
                    registerListener();
                }else{
                    imageButton.setImageResource(R.drawable.button_icon_red);
                    unregisterListener();
                    enviar("N");
                    enviar("\n");
                }
                sensorActive = !sensorActive;
            }
        });
    }

    public void registerListener() {
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void unregisterListener() {
        sensorManager.unregisterListener(this);
    }

    private void connectBT() {
        try {
            btSocket = bc.getBTSocket(deviceAddress);
            outputStream = btSocket.getOutputStream();
            inputStream = btSocket.getInputStream();
        } catch (Exception e) {
            Log.e("MyError", e.getMessage());
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float axisX;
        float axisY;

        axisX = event.values[0];
        axisY = event.values[1];

        if(btSocket == null)
            ejeVertical.setText("socket null");
        else {
            outputChange(axisX, axisY);
            recibir();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void outputChange(Float value0, Float value1) {

        StringBuilder sb = new StringBuilder();
        String output = "NN";
        /*

        F = FORWARD
        B = BACKWARDS

        L = LEFT
        R = RIGHT

        N = NEUTRO // 0

        F-8-L (valor a enviar)

         */

        int x = Math.round(value0);
        int y = Math.round(value1);

        if((y < 10 || y > -10) && (y != 0 || x !=0)) {
            if (y >= 0) {
                enviar("B");
                enviar("-");
                enviar(String.valueOf(y));
            } else if (y < 0) {
                enviar("F");
                enviar("-");
                int temp = Math.abs(y);
                enviar(String.valueOf(temp));
            }


            if (x > 2) {
                enviar("-");
                enviar("L");
            } else if (x < -2) {
                enviar("-");
                enviar("R");
            }
            else {
                enviar("-");
                enviar("0");
            }

            //output = sb.toString();
            enviar("\n");
        }
        else {
            enviar("N");
            enviar("\n");
        }

        //return output;
    }

    private void recibir() {
        if (btSocket != null) {
            try {
                int byteCount = inputStream.available();
                if(byteCount > 0) {
                    byte[] rawBytes = new byte[byteCount];
                    inputStream.read(rawBytes);
                    String string = new String(rawBytes, 0, byteCount);

                    ejeVertical.setText(string);
                }
            }
            catch (IOException e) {
                Log.e("MyError", e.getMessage());
            }
        }
    }

    public void enviar(String text) {
        if (btSocket!=null) {
            try {
                byte[] bytes = text.getBytes();
                outputStream.write(bytes);
            }
            catch (IOException e) {
                Log.e("MyError", e.getMessage());
            }
        }
    }

}
