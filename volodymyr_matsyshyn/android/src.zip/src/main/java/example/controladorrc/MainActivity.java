package example.controladorrc;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import example.controladorrc.fragments.ButtonsFragment;
import example.controladorrc.fragments.JoystickFragment;
import example.controladorrc.fragments.SensorsFragment;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private BluetoothAdapter bluetoothAdapter;
    private TextView tv_status_bt;
    private TextView tv_status_text;
    private Button btn_active_bt;
    private Button btn_connect_device;

    private String deviceAddress = null;

    private Handler handler;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        handler = new Handler();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        tv_status_text = (TextView) findViewById(R.id.tv_status_text);
        tv_status_bt = (TextView) findViewById(R.id.tv_status_bt);
        btn_active_bt = (Button) findViewById(R.id.btn_active_bt);
        btn_connect_device = (Button) findViewById(R.id.btn_connect_device);

        checkOne();
        checkBTstatus();
        btn_active_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableBTIntent);
                handler.postDelayed(buttonOnOff, 4000);
            }
        });

        btn_connect_device.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent connectBT = new Intent(getApplicationContext(), PopUpDevices.class);
                startActivity(connectBT);
                btn_connect_device.setVisibility(View.GONE);
            }
        });
        handler.postDelayed(buttonConnect, 4000);
    }

    private Runnable buttonConnect = new Runnable() {
        @Override
        public void run() {
            checkOne();
        }
    };

    private Runnable buttonOnOff = new Runnable() {
        @Override
        public void run() {
            checkBTstatus();
        }
    };

    public void checkOne() {
        if(bluetoothAdapter.isEnabled())
            btn_connect_device.setVisibility(View.VISIBLE);
        else
            btn_connect_device.setVisibility(View.INVISIBLE);
    }

    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        Bundle bundle1 = new Bundle();
        bundle1 = getIntent().getExtras();

        if(bundle1 == null){
            Toast.makeText(this, "bundle null", Toast.LENGTH_LONG).show();
        }

        else {
            deviceAddress = bundle1.getString("deviceAddress");
            Toast.makeText(this, deviceAddress, Toast.LENGTH_LONG).show();
        }

        Fragment selectedFragment = null;

        if(!bluetoothAdapter.isEnabled()) {
            Log.d("s", "BT not enabled");
            Toast.makeText(this, "El Bluetooth no está activado", Toast.LENGTH_SHORT).show();
        }
        else {
            if (id == R.id.buttons) {
                selectedFragment = new ButtonsFragment();
            } else if (id == R.id.joystick) {
                Toast.makeText(this, "En proceso de desarrollo", Toast.LENGTH_SHORT).show();
                //selectedFragment = new JoystickFragment();
            } else if (id == R.id.sensors) {
                selectedFragment = new SensorsFragment();
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("deviceAddress", deviceAddress);

            selectedFragment.setArguments(bundle2);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();

            tv_status_bt.setVisibility(View.GONE);
            tv_status_text.setVisibility(View.GONE);
            btn_active_bt.setVisibility(View.GONE);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void checkBTstatus() {
        if (!bluetoothAdapter.isEnabled()){
            tv_status_bt.setBackgroundColor(getResources().getColor(R.color.colorRed));
            btn_active_bt.setVisibility(View.VISIBLE);
        }
        else {
            tv_status_bt.setBackgroundColor(getResources().getColor(R.color.colorGreen));
            btn_active_bt.setVisibility(View.GONE);
            checkOne();
        }
    }

}
