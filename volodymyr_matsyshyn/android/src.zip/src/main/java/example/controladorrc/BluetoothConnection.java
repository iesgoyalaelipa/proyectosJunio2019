package example.controladorrc;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;

/**
    Clase para establecer la conexión con la dirección
    Recibe dirección y devuelve BluetoothSocket (que permitirá conseguir los flujos de entrada y salida)
 */

public class BluetoothConnection {

    private BluetoothAdapter myBluetooth;
    private BluetoothSocket btSocket;

    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public BluetoothConnection() {

        myBluetooth = BluetoothAdapter.getDefaultAdapter();

    }

    public BluetoothSocket getBTSocket(String BT_ADRESS)
    {
        BluetoothDevice btDevice = null;
        try
        {
            Set<BluetoothDevice> pairedDevices = myBluetooth.getBondedDevices();
            // If there are paired devices
            if (pairedDevices.size() > 0) {
                // Loop through paired devices
                for (BluetoothDevice device : pairedDevices) {

                    if(device.getAddress().equals(BT_ADRESS))
                        btDevice = device;
                }
            }

            if(btDevice == null)
                Log.e("MyError", "Bluetooth Device is NULL");
            else {
                btSocket = btDevice.createInsecureRfcommSocketToServiceRecord(myUUID);
                btSocket.connect();
            }
        }
        catch (IOException e) {
            Log.e("MyError", e.getMessage());
        }

        return btSocket;
    }

}