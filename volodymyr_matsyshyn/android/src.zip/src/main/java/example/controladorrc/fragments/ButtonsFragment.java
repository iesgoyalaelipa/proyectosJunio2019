package example.controladorrc.fragments;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.IOException;
import java.io.OutputStream;

import example.controladorrc.BluetoothConnection;
import example.controladorrc.R;

public class ButtonsFragment extends Fragment {

    private Button arrowUp;
    private Button arrowDown;
    private Button arrowLeft;
    private Button arrowRight;

    private String deviceAddress = null;
    private OutputStream outputStream;
    private BluetoothAdapter myBluetooth = null;
    private BluetoothSocket btSocket = null;

    private BluetoothConnection bc;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_fragment_buttons, container, false);

        arrowUp = (Button) view.findViewById(R.id.arrowUp);
        arrowDown = (Button) view.findViewById(R.id.arrowDown);
        arrowLeft = (Button) view.findViewById(R.id.arrowLeft);
        arrowRight = (Button) view.findViewById(R.id.arrowRight);

        bc = new BluetoothConnection();

        if (getArguments() != null) {
            deviceAddress = getArguments().getString("deviceAddress");
            btSocket = bc.getBTSocket(deviceAddress);
        }

        if(btSocket != null) {
            try {
                outputStream = btSocket.getOutputStream();
            } catch (Exception e){
                Log.d("MyError", e.getMessage());
            }
        }

        myBluetooth = BluetoothAdapter.getDefaultAdapter();

        if (outputStream != null) {

            arrowUp.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() == MotionEvent.ACTION_DOWN) {
                        sendCommands(1);
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        sendCommands(5);
                    }
                    return true;
                }
            });

            arrowDown.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() == MotionEvent.ACTION_DOWN) {
                        sendCommands(2);
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        sendCommands(5);
                    }
                    return true;
                }
            });

            arrowLeft.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() == MotionEvent.ACTION_DOWN) {
                        sendCommands(3);
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        sendCommands(5);
                    }
                    return true;
                }
            });

            arrowRight.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(event.getAction() == MotionEvent.ACTION_DOWN) {
                        sendCommands(4);
                    } else if (event.getAction() == MotionEvent.ACTION_UP) {
                        sendCommands(5);
                    }
                    return true;
                }
            });
        }
        return view;
    }

    public void sendCommands(int type) {

        /*
        1 = FORWARD
        2 = BACKWARDS
        3 = LEFT
        4 = RIGHT

        N = NEUTRO // 0

        F-8-L (valor a enviar)
        */

        if(type == 1) {
            enviar("F");
            enviar("-");
            enviar(String.valueOf(9));
            enviar("-");
            enviar("0");
            enviar("\n");
        }
        else if (type == 2) {
            enviar("B");
            enviar("-");
            enviar(String.valueOf(9));
            enviar("-");
            enviar("0");
            enviar("\n");
        }
        else if(type == 3) {
            enviar("F");
            enviar("-");
            enviar(String.valueOf(0));
            enviar("-");
            enviar("L");
            enviar("\n");
        }
        else if(type == 4) {
            enviar("F");
            enviar("-");
            enviar(String.valueOf(0));
            enviar("R");
            enviar("\n");
        }
        else if (type == 5) {
            enviar("N");
            enviar("\n");
        }
    }

    public void enviar(String text)
    {
        if (btSocket!=null)
        {
            try
            {
                byte[] bytes = text.getBytes();
                outputStream.write(bytes);
            }
            catch (IOException e)
            {
                Log.e("MyError", e.getMessage());
            }
        }
    }
}
