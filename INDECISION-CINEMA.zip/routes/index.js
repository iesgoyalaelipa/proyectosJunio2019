let express = require('express');
let router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'INDECISION CINEMA' });
});

/* Ruta de prueba */
router.get('/homepage', function(req, res, next) {
  res.render('homepage', { title: 'PRUEBA' });
});

/* Ruta de prueba */
router.get('/asientos', function(req, res, next) {
  res.render('asientos', { title: 'ASIENTOS' });
});


/* Ruta de prueba */
router.get('/sits', function(req, res, next) {
  res.render('sits', { title: 'ASIENTOS' });
});

/* Ruta de prueba */
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'INDECISION CINEMA' });
});

module.exports = router;
