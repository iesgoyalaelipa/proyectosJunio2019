let express = require('express');
let mysqlConnection = require ('../database/database_connection');
let router = express.Router();

/* Ruta de Home/Index */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'INDECISION CINEMA' });
});

/* Ruta de Asientos */
router.get('/sits', function(req, res, next) {
  res.render('sits', { title: 'ASIENTOS' });
});

/* Ruta de Login */
router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Log In' });
});

/* Ruta de Error */
router.get('/error', function(req, res, next) {
  res.render('error', { title: 'Error' });
});

/* Ruta de Submit */
router.get('/submit', function(req, res, next) {
  res.render('submit', { title: 'Submit' });
});

/* Ruta de Cartelera */
router.get('/cartelera', function(req, res, next) {
  res.render('cartelera', { title: 'Cartelera' });
});


/**
 * Consulta a conexión a BBDD
 */

router.post('/login', function (req, res) {
  let form = req.body;
  console.log('paso por aquí');
  console.log(form);
  mysqlConnection.query("SELECT * FROM usuario WHERE email=? AND password=?", [form.email, form.password], function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    res.render('submit', { title: 'Log In', result: result});
  });

  mysqlConnection.end();
});

module.exports = router;