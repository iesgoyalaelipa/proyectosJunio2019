let mysql = require('mysql');                // importar mysql
//const config = require();                  // para fichero externo con las credenciales
//const dbConfig = config.db;

let connection = mysql.createConnection({
   host: 'localhost',
   database: 'indecision_cinema',
   user: 'indecision_cinema',
   password: 'totoro130891'
});

connection.connect(function(err) {
   if (err) {
      console.error('Error connecting: ' + err.stack);
      return;
   }
   console.log('Connected as id ' + connection.threadId);
});

module.exports = connection;